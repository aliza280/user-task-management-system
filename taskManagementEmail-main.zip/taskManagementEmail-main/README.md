# taskManagementEmail

pip install fastapi  uvicorn  sqlalchemy httpx itsdangerous jinja2  passlib[bcrypt] dotenv  python-jose[cryptography]  pydantic  python-multipart

# .env file setup
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REDIRECT_URI=http://localhost:8000/auth/google/callback

SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME= your gmail
SMTP_PASSWORD=
EMAIL_FROM= your gmail 
SECRET_KEY=your-secret-key-here
