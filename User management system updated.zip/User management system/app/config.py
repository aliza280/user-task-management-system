import os
from pydantic import BaseSettings


class Settings(BaseSettings):
    # Secret key for signing JWT tokens
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your_default_secret_key")

    # Algorithm used for JWT
    ALGORITHM: str = "HS256"

    # Expiration time for JWT in minutes (default 30 minutes)
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    # Database connection string (using SQLite in this case)
    SQLALCHEMY_DATABASE_URL: str = os.getenv("SQLALCHEMY_DATABASE_URL", "sqlite:///./test.db")

    # For email settings (you can add more as needed)
    SMTP_HOST: str = os.getenv("SMTP_HOST", "smtp.example.com")
    SMTP_PORT: int = 587
    SMTP_USER: str = os.getenv("SMTP_USER", "your_email@example.com")
    SMTP_PASSWORD: str = os.getenv("SMTP_PASSWORD", "your_email_password")

    class Config:
        # This tells Pydantic to load settings from environment variables.
        env_file = ".env"
        env_file_encoding = "utf-8"


# Create an instance of the settings to be used throughout the application
settings = Settings()
