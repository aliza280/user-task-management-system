from pydantic import BaseModel
from typing import Optional

# Pydantic schema for creating and updating a task
class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None  # Optional description

# Schema for creating a task (inherit from TaskBase)
class TaskCreate(TaskBase):
    pass

# Schema for reading a task (inherits from TaskBase)
class TaskRead(TaskBase):
    id: int  # Task ID (read-only)

    class Config:
        orm_mode = True  # Allow SQLAlchemy models to be converted to Pydantic models

# Schema for updating a task (inherits from TaskBase)
class TaskUpdate(TaskBase):
    pass
